/**
 * Created by Kang on 27/05/15.
 */
var cms = 'wordpress';