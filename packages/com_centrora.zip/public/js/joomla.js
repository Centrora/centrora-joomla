ajaxurl = 'index.php';
var cms = 'joomla';
jQuery(document).ready(function($){
	$('link[rel=stylesheet][href~="template.css"]').remove();
});