<?php
$log = array (
  0 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  1 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  2 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  3 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  4 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  5 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  6 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  7 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  8 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  9 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  10 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  11 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  12 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  13 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  14 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  15 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  16 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  17 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  18 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  19 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  20 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  21 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  22 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  23 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  24 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  25 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  26 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  27 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  28 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  29 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  30 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  31 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  32 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  33 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  34 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  35 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  36 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  37 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  38 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  39 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  40 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  41 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  42 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  43 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  44 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  45 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  46 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  47 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  48 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  49 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  50 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  51 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  52 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  53 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  54 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  55 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  56 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  57 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  58 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  59 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  60 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  61 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  62 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  63 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  64 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  65 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  66 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  67 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  68 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  69 => 
  array (
    'ip' => NULL,
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  70 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  71 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  72 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  73 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  74 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  75 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  76 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  77 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  78 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  79 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  80 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  81 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  82 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  83 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  84 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  85 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  86 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  87 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  88 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  89 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  90 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  91 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  92 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  93 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  94 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  95 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  96 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  97 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  98 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  99 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
  100 => 
  array (
    'ip' => 'test ip',
    'methodname' => 'Check Malicious User Agent',
    'message' => 'HTTP_USER_AGENT is not set',
    'datetime' => '2018-03-21 03:23:02',
  ),
);