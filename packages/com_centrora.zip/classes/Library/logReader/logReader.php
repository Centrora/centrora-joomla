<?php
/**
 * Created by PhpStorm.
 * User: suraj
 * Date: 13/05/2016
 * Time: 2:11 PM
 */
if (!defined('OSE_FRAMEWORK') && !defined('OSE_ADMINPATH') && !defined('_JEXEC'))
{
    die('Direct Access Not Allowed');
}
require(dirname(__FILE__)."/Process.php");
class logReader {

    public function test()
    {

    }

}