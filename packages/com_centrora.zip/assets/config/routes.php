<?php

return array(
	'default' => array(
		'(/<controller>(/<action>(/<id>)))', 
		array(
			'controller' => 'hello',
			'action' => 'index'
		),
	),
);
