<div id="bupOnedriveWrapper">
    <div id="bupOnedriveAlerts"></div>
    <a href="<?php echo $url; ?>"
       class="button button-primary button-large oneDriveAuthenticate"><?php _e('Authenticate', BUP_LANG_CODE); ?></a>
</div>
