<div id="bupOnedriveWrapper">
    <div id="bupOnedriveAlerts"></div>

    <div>
        <button class="onedriveLogout button button-primary button-large">
            <?php echo __('Logout', BUP_LANG_CODE); ?>
        </button>
    </div>
</div>
